const multer = require('multer');
const router = require('express').Router();
const middlewares = require('../helper/middlewares');

const user = require('../controller/user');

router.post('/registration', middlewares.imageSaveMiddleWares, user.registration);
router.get('/users', user.allUsers);
router.post('/login',user.login);
router.put('/update',user.update);
router.delete('/delete',user.delete);

module.exports = router;