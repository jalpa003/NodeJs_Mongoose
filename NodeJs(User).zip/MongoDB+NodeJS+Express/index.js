const config = require('./helper/config');
const mongoose = require('mongoose');
const express = require('express');
const bodyParser = require('body-parser');

const routes = require('./router/app');
const app = express();

app.use(bodyParser.json({limit:'50mb'}));

app.use(bodyParser.urlencoded({limit:'50mb', extended: true, parameterLimit:1000000 }));

mongoose.connect(`mongodb+srv://${config.data_source.user}:${config.data_source.password}@cluster0.m6xwi.mongodb.net/${config.data_source.database}?retryWrites=true&w=majority`,
    config.data_source.options,
    (err) => {
        err ? console.error("DB CONNECTION ERROR :", err) : console.info("Hey, the connection is established with DB")
    });

app.get('/', (req, res) => { res.send("app working"); });

app.use('/api', routes);

app.listen(config.port, (err) => { if (err) console.log(err); });