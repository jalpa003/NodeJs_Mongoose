const middlewares = require('../helper/middlewares');
const schema = require('../model/schema');

module.exports.registration = async (req, res) => {
    const registration = new schema.registrationSchema({
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        email: req.body.email,
        password: req.body.password,
        city: req.body.city,
        state: req.body.state,
        country: req.body.country,
        img: req.file.filename,
    });

    try {
        const saveData = await registration.save();
        if (saveData) res.send(middlewares.responseMiddleWares(undefined, true, "registered successfully"));
        else res.send(middlewares.responseMiddleWares(undefined, false, "not registered"));
    }
    catch (err) { res.send(middlewares.responseMiddleWares(undefined, false, err)); }
}

module.exports.allUsers = async (req, res) => {
    try {
        const allUsers = await schema.registrationSchema.find();
        if (allUsers.length > 0) res.send(middlewares.responseMiddleWares(allUsers, true, "data extracted"));
        else res.send(middlewares.responseMiddleWares(undefined, false, "data not extracted"));
    }
    catch (err) { res.send(middlewares.responseMiddleWares(undefined, false, err)); }
}

module.exports.login = async(req,res) =>{
    try{
        const users = await schema.registrationSchema.findOne({email : req.body.email , password : req.body.password})
        if(users) res.send(middlewares.responseMiddleWares(undefined,true,"Login successfully!"));
        else res.send(middlewares.responseMiddleWares(undefined,false,"Email or Password Invalid!!!"));
    }
    catch (err) { res.send(middlewares.responseMiddleWares(undefined, false, err)); }
}
module.exports.update = async (req,res)=>{
    const  id = req.body.id 
    const data ={
        firstname : req.body.firstname,
        lastname : req.body.lastname
    }
    try{
        const update = await schema.registrationSchema.findByIdAndUpdate(id,data);

        if(update) res.send(middlewares.responseMiddleWares(undefined,true,"User Updated successfully!"));
        else res.send(undefined,false,"Something went wrong!!");
    }
    catch(err) { res.send(middlewares.responseMiddleWares(undefined, false, err)); }
}
module.exports.delete = async(req,res)=>{
    try{
        const id = req.body.id;
        const del = await schema.registrationSchema.remove({_id:id})
        if(del) res.send(middlewares.responseMiddleWares(undefined,true,"User deleted successfully!"));
        else res.send(middlewares.responseMiddleWares(undefined,false,"Something went wrong!"));
    }
    catch(err) { res.send(middlewares.responseMiddleWares(undefined, false, err)); }
}