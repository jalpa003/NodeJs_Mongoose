var config = {
    port: 3000,
    data_source: {
        user: "",
        password: "",
        database: "",
        options: {
            socketTimeoutMS: 0,
            connectTimeoutMS: 0,
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useFindAndModify: false,
            useCreateIndex: true,
        }
    }
}

module.exports = config;